# Module proclab
import os
import sys
import time


# Creates n processes. All of them execute the f function
# Returns the number of created children 
# Syscalls needed: os.fork
# If an error occurs, raise the exception 
def createChildren(n,f):
       return 0

# Argument status is a list, the return of os.wait()
# Returns a list of two numbers and a string: 
# the child's pid, 
# the child's exit value or signumber 
# the  cause of child's termination. "exit" or "signal"
# Syscalls allowed: none
# Functions needed: os.WTERMSIG(...), os.WEXITSTATUS(...), os.WTERMSIG(...)
def check_status(status): 
       return list()


# Waits for n children
# Returns a list of tuplas with the pid and 
# the exit value or signal number of the n dead children
# Syscalls needed: os.wait
# If an error occurs, raise the exception
def waitNChildren(n):
        return list()

# Waits for all already dead children
# Returns a list of tuplas with the status list returned by the syscall
# Syscalls needed: os.waitpid
def waitChildren():
        return list()

# Sends signal s to process p
# Returns 0 on success
# Syscalls needed: os.kill
# If an error occurs, raise the exception
def sendSignal(p,s):
        return 0

# Set the handler for signal signalnum to the function handler
# On sucess returns the previous signal handler 
# Syscalls needed: signal.signal
# If an error occurs, raise the exception and returns -1
def sigAction(s,f):
        return 0

# replaces the current process image with a new process image
# path is the complete file name of a executable, 
# args, is a list of the arguments of path
# Syscalls needed: os.execlp
# If an error occurs, raise the exception
def chgProcImg(path,args):
        return 0

# Creates a process and replaces the child process image with program named f
# Second parameter, a, is a list of the arguments of f
# Returns the pid of the child
# Syscalls needed: os.fork, os.execvp
# If an error occurs, raise the exception 
def launchCmd(f,a):
        return 0

# Example of creating a process
# 
def mayThe4th():
        r=0xfa
        try:
            pid = os.fork()
        except OSError:
           raise 
        else:
            if pid == 0:
                print ("Who are you?")
                os._exit(r)
            else:
                print("I am your father")
                try:
                        [a,b]=os.wait()
                except OSError:
                        raise
                else:        
                        print("Luke is dead")    
        return 0