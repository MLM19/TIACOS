#  
#   TIACOS Data Lab 
#   
#   <Please put yours names  here>
#   
#   datalab.py - Source file with your solutions to the Lab.
#            This is the file you will hand in to your instructor.  
#  


# Instructions to Students:
 
# STEP 1: Read the following instructions carefully.
 
#  You will provide your solution to the Data Lab by
# editing the collection of functions in this source file.

# INTEGER CODING RULES:
 
#   Replace the "return" statement in each function with one
#   or more lines of Python code that implements the function. Your code 
#   must conform to the following style:

#   def Funct(arg1, arg2, ...):
#       # brief description of how your implementation works 
#       var1 = Expr1
#       ...
#       varM = ExprM

#       varJ = ExprJ
#       ...
#       varN = ExprN
#       return ExprR
#   

#   Each "Expr" is an expression using ONLY the following:
#   1. Integer constants 0 through 255 (0xFF).
#   2. Function arguments and local variables (no global variables).
#   3. Unary integer operations  ~
#   4. Binary integer operations & ^ | + * - << >>
#   5. Logical operators and, or, not

    
#   Some of the problems restrict the set of allowed operators even further.
#   Each "Expr" may consist of multiple operators. You are not restricted to
#   one operator per line.

#   You are expressly forbidden to:
#   1. Use any control constructs such as if, while, for, etc.
#   2. Define or use any macros.
#   3. Define any additional functions in this file.
#   4. Call any functions.
#   5. Use any other operations
#   6. Use any form of casting.
#   7. Use any data type other than integer and boolean.  This implies that you
#      cannot use arrays, or lists.

 
#   You may assume that your machine:
#   1. Uses 2s complement, 64-bit representations of integers.
#   2. Performs right shifts arithmetically.
#   3. Has unpredictable behavior when shifting if the shift amount
#      is less than 0 or greater than 63.

# EXAMPLES OF ACCEPTABLE CODING STYLE:
# 
# #pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
#
def pow2plus1(x):
   # exploit ability of shifts to compute powers of 2 
   return (1 << x) + 1
#   

#   
#   # pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
#    
def pow2plus4(x):
   # exploit ability of shifts to compute powers of 2 
   result = (1 << x)
   result += 4
   return result


# FLOATING POINT CODING RULES

# For the problems that require you to implement floating-point operations,
# the coding rules are less strict.  You are allowed to use looping and
# conditional control.  You are allowed to use integers.
# You can use arbitrary integer constants. 
# You can use any arithmetic, logical, 
# or comparison operations on int or #unsigned data.

# You are expressly forbidden to:
#   1. Define or use any macros.
#   2. Define any additional functions in this file.
#   3. Call any functions.
#   4. Use any form of casting.
#   5. Use any data type other than int or unsigned.  This means that you
#      cannot use arrays, structs, or unions.
#   6. Use any floating point data types, operations, or constants.

# STEP 2: Modify the following functions according the coding rules.

 
 #
 # bitXor - x^y using only ~ and & 
 #  Example: bitXor(4, 5) = 1
 #  Legal ops: ~ &
 #  Max ops: 14
 #  Rating: 2
 
def bitXor(x, y):

    return


# 
# tmin - return minimum two's complement integer, n = 32b
#   Legal ops: ! ~ & ^ | + << >>
#   Max ops: 4
#   Rating: 1
#
def tmin():
    return

#  
#   negate - return -x 
#   Example: negate(1) = -1.
#   Legal ops: ! ~ & ^ | + << >>
#   Max ops: 5
#   Rating: 1
#  
def negate(x):
    return

# 
#  getByte - Extract byte n from word x
#  Bytes numbered from 0 (least significant) to 3 (most significant)
#  Examples: getByte(0x12345678,1) = 0x56
#  Legal ops: not ~ & ^ | + << >>
#  Max ops: 6
#  Rating: 3
#  
def getByte(x, n):
    return


#byteSwap - swaps the nth byte and the mth byte
#Examples: byteSwap(0x12345678, 1, 3) = 0x56341278
#	   byteSwap(0xDEADBEEF, 0, 2) = 0xDEEFBEAD
#You may assume that 0 <= n <= 3, 0 <= m <= 3
#Legal ops: ! ~ & ^ | + << >>
#Max ops: 25
#Rating: 4
def byteSwap (x, n, m):
    return 


# 
#  floatIsEqual - Compute f == g for floating point arguments f and g.
#  Both the arguments are passed as 32b integer, and
#  they are to be interpreted as the bit-level representations of
#  single-precision floating point values.
#  If either argument is NaN, return 0.
#  +0 and -0 are considered equal.
#  Legal ops: Any integer operations incl. ||, &&. also if, while
#  Max ops: 25
#  Rating: 3
#  For instance:
#   -0.000000 == 2147483648 == 0.000000 == 0
#  
def floatIsEqual(uf, ug):
    return

#  
#  floatAbsVal - Return bit-level equivalent of absolute value of f for
#  floating point argument f.
#  Both the argument and result are passed as integer numbers, but
#  they are to be interpreted as the bit-level representations of
#  single-precision floating point values.
#  When argument is NaN, return argument..
#  Legal ops: Any integer/unsigned operations incl. and, or, also if, while
#  Max ops: 10
#  Rating: 2
#  
def floatAbsVal(f):
    return

#
# floatPower2 - Return bit-level equivalent of the expression 2.0^x
#   (2.0 raised to the power x) for any 32-bit integer x.
#
#    The unsigned value that is returned should have the identical bit
#    representation as the single-precision floating-point number 2.0^x.
#    If the result is too small to be represented as a denorm, return
#    0. If too large, return +INF.
#
#    Legal ops: Any integer/unsigned operations incl. ||, &&. Also if, while
#    Max ops: 30
#    Rating: 4
#
def floatPower2(x):
    return 