### IOLAB 

# ioLab.py

import os

# Put your name(s) here: María López

# This module contains all the functions you must program. 
# 
# Instructions to Students:
 
# STEP 1: Read the following instructions carefully.
 
#  You will provide your solution to the IO Lab by
# editing the collection of functions in this source file.

# For input/output, you only can use os.read() and os.write() functions. 
# print() and similar high level functions are not allowed.

# Argument q is a byte that represents the quality score. 
# It is a number between 0 - 40
# This function returns a float number
def err(q):
    e = 10**(-(int.from_bytes(q,"little"))/10) 
    return e

# Example!
# Argument filename is a path to the fastq file to  read
# This function opens filename and reads the header and the sequence of bases and prints the last on screen
def showSequence(filename):
    fd = os.open(filename, os.O_RDONLY)  # Open the file in read-only mode
    line = readLine(fd)  # Read the first line (header) and discard it
    sequence = readLine(fd)  # Read the second line (sequence)
    os.write(1, b"File: " + filename.encode() + b" First sequence\n")
    writeLine(sequence)  # Write the sequence to the standard output
    os.write(1, b'\n')
    os.close(fd)  # Close the file descriptor
    return 0

# str is a vector of ASCII bytes representing digits from 0 - 9
# function atoi converts str to integer.  The behavior is must be the same as 
# int(b''.join(str))
# example: if str = [b'3',b'0',b'9'] then  atoi(str) =  309
def atoi(str):
    result = 0

    for byte in str:
        digit = byte - 48 #48 is ASCII value of '0'--> ord(b'0')
        result = result * 10 + digit

    return result

# Example usage
# input_bytes = bytearray(os.read(0, 3))  # Read 3 bytes from input
# result = atoi(input_bytes)
# output_bytes = str(result).encode()  # Convert the integer result to bytes
# os.write(1, output_bytes)  # Write the bytes to output

#This code reads 3 bytes from the input using os.read(), converts each byte to an integer digit by subtracting the ASCII value of '0', and calculates the resulting integer. It then converts the integer back to bytes using str(result).encode() and writes the bytes to the output using os.write().


# line is a bytestring ended by '\n' that contains b'length=<nnn>', where <nnn> are ascii digits
# readLenght(line) must return an integer
# Example: if word=b'length=309', then readLenght(word) returns 309
def readLength(line):
    length_bytes = bytearray()
    i = line.find(b'length=') + 7  # Start index after 'length='

    # Extract the ASCII digits until '\n' is encountered
    while i < len(line) and line[i] != 10:  # ASCII value for '\n'
        length_bytes.append(line[i])
        i += 1

    # Convert the extracted bytes to an integer
    length = 0
    for byte in length_bytes:
        digit = byte - 48  # ASCII value of '0'
        length = length * 10 + digit

    return length
#The code extracts the numerical value following "length=" in a byte string and returns it as an integer.



# Argument fd is a file descriptor of an already open file
# This functions returns a bytestring ended by b'\n' read from 
# the file descriptor 

def readLine(fd):
    line_bytes = bytearray()
    byte = os.read(fd, 1)
    while byte != b'\n' and byte != b'':
        line_bytes += byte
        byte = os.read(fd, 1)
    return bytes(line_bytes)

 

# Argument line is a Fastq line in a bytestring. 
# That's, the return of readLine(fd).
# This function writes all the line to standard output
def writeLine(line):
    if isinstance(line, int):  # Check if line is an integer
        line = str(line).encode()  # Convert the integer to bytes
    os.write(1, line)  # Write the line to standard output


# Argument filename is a path to the fastq file to  read
# This function opens filename and reads its first line, printing on screen
# the name of the sequence and the number of bases
#
def showHeader(filename):
    fd = os.open(filename, os.O_RDONLY)  # Open the file in read-only mode
    line = readLine(fd)  # Read the first line from the file
    os.write(1, b"File: " + filename.encode() + b" Fastq header\n")
    os.write(1, b"Name: " + line)
    length = readLength(line)
    os.write(1, b"-Number of bases: " + str(length).encode() + b"\n")
    os.close(fd)  # Close the file descriptor


# Argument filename is a path to the fastq file to  read
# This function opens filename and reads its bases. For each base, 
# prints a pair base --> quality
def showSeqQlty(filename):
    fd = os.open(filename, os.O_RDONLY)
    line = readLine(fd).decode()
    seqLine = readLine(fd).decode()
    _ = readLine(fd).decode()  # Discard the line starting with '+'
    qltyLine = readLine(fd).decode()
    os.close(fd)

    # Prepare the output string with all the base, quality pairs
    output = ""
    quality_list = []

    for base, quality in zip(seqLine, qltyLine):
        quality_num = ord(quality) - 33
        output += f"{base} --> {quality_num} "
        quality_list.append((base, quality_num))

    os.write(1, b"File: " + filename.encode() + b" First sequence and qualities\n")
    os.write(1, output.encode() + b"\n") 

    return quality_list

# Arguments are bytestrings sequence of bases and its correspondence qualities
# The function returns de worst pair, ie, the base with the lowest quality
# Returns a tuple (base, quality) of the worst pair base -> quality
def worstQlty(sequence_line, quality_line):
    worst_base = None
    worst_quality = 40  # Initializing with a high value
    for base, quality in zip(sequence_line, quality_line):
        quality_val = int(quality)
        if quality_val < worst_quality:
            worst_base = base
            worst_quality = quality_val
    return worst_base, worst_quality
#the code compares the qualities of each base in the sequence and returns the base-quality pair with the lowest quality.

# Argument filename is a path to the fastq file to  read
# This function opens filename and reads its bases. 
# It shows the worst pair. 
# Prints a pair base --> quality
def showWorstQlty(file_name):
    with open(file_name, 'r') as file:
        sequence_line = None
        quality_line = None
        worst_quality = float('inf')
        worst_base = None

        for line_num, line in enumerate(file):
            if line_num % 4 == 1:  # Sequence line
                sequence_line = line.strip()
            elif line_num % 4 == 3:  # Quality line
                quality_line = line.strip()
                for base, quality in zip(sequence_line, quality_line):
                    quality_val = ord(quality) - 33
                    if quality_val < worst_quality:
                        worst_quality = quality_val
                        worst_base = base

    # Print the result
    os.write(1, b"File: " + file_name.encode() + b" The worst quality of the first sequence\n")
    os.write(1, f"The worst quality: {worst_base} --> {worst_quality}\n".encode())
