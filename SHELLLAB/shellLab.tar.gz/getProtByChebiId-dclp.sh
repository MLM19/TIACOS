curl -s "https://www.ebi.ac.uk/chebi/viewDbAutoXrefs.do?d-1169080-e=1&6578706f7274=1&chebiId=${1}&dbName=UniProt" | grep -E "MISCELLANEOUS|DISRUPTION PHENOTYPE" | awk -F',' '{print $1}' | xargs -I @ wget -q -O - "https://www.uniprot.org/uniprot/@.txt" | grep "DOI" | awk -F ";" '{print$2}' > ${1}_DOIs.txt

