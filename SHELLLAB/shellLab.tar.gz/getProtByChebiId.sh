curl -o ${1}.csv 'https://www.ebi.ac.uk/chebi/viewDbAutoXrefs.do?d-1169080-e=1&6578706f7274=1&chebiId='${1}'&dbName=UniProt'
